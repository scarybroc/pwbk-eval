# PT Eval Quick Interview

Mobile-friendly GitHub Pages web app for fast PT eval interview notes.

## Upload

Upload these files to the root of the repository:

- `index.html`
- `manifest.json`
- `sw.js`
- `icon-192.png`
- `icon-512.png`

GitHub Pages should use:

- Branch: `main`
- Folder: `/ (root)`

Your site should appear at:

`https://scarybroc.github.io/pwbk-eval/`

## iPhone

Open the website in Safari, tap **Share**, then **Add to Home Screen**.

## Privacy

The app stores entries locally in the browser. Avoid entering protected health information on an unapproved personal device.
